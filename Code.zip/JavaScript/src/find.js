"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buscarObjeto = buscarObjeto;
function buscarObjeto(array, criterio) {
    return array.find(criterio);
}
