"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.creditosDeTypeScriptEspanol = creditosDeTypeScriptEspanol;
function creditosDeTypeScriptEspanol() {
    console.log("Tiziano Luzi Ramos");
    console.log("ChatGPT(El 2% del codigo)");
}
