"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.consologuear = consologuear;
function consologuear(...args) {
    console.log(...args);
}
