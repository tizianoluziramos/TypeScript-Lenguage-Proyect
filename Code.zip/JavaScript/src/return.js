"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.retornar = retornar;
function retornar(valor) {
    return valor;
}
