export function retornar<T>(valor: T): T {
    return valor;
}