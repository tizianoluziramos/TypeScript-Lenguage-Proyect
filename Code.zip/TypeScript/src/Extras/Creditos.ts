export function creditosDeTypeScriptEspanol(): void {
    console.log("Tiziano Luzi Ramos")
    console.log("ChatGPT(El 3% del codigo)");
}