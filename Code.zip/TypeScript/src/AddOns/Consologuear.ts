export function consologuear(...args:any): void {
    console.log(...args);
}