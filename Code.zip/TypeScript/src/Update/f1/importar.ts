import { FrancoColapinto, FrancoColapintoSubExtensionForAPICallDoNotUserPleaseItsjustANAPI, FranquitoAPICall, ApiResponse } from './FrancoColapinto.ts'
import { MaxVerstappen, MaxVerstappenReturnThenCode } from './MaxVerstappen.ts'

export {
    FrancoColapinto,
    FrancoColapintoSubExtensionForAPICallDoNotUserPleaseItsjustANAPI,
    FranquitoAPICall,
    ApiResponse,
    MaxVerstappen,
    MaxVerstappenReturnThenCode
}