import { Si } from './if'

export function si(condicion: boolean) {
  return new Si(condicion);
}

